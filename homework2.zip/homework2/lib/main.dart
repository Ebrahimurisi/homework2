import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ShoeDashboard(),
    );
  }
}

class Shoe {
  String name;
  String imageUrl;
  double price;
  double rating;

  Shoe({
    required this.name,
    required this.imageUrl,
    required this.price,
    required this.rating,
  });
}

class ShoeDashboard extends StatefulWidget {
  @override
  _ShoeDashboardState createState() => _ShoeDashboardState();
}

class _ShoeDashboardState extends State<ShoeDashboard> {
  List<Shoe> shoes = [
    Shoe(name: "Anmal 1", imageUrl: "https://via.placeholder.com/150", price: 100, rating: 4.5),
    Shoe(name: "Anmal 2", imageUrl: "https://via.placeholder.com/150", price: 100, rating: 4.0),
    Shoe(name: "Anmal 3", imageUrl: "https://via.placeholder.com/150", price: 100, rating: 4.2),
    Shoe(name: "Anmal 4", imageUrl: "https://via.placeholder.com/150", price: 100, rating: 4.6),
  ];

  List<Shoe> filteredShoes = [];
  List<Shoe> secondList = [];

  @override
  void initState() {
    super.initState();
    filteredShoes = shoes;
    secondList = shoes.reversed.toList(); // قلب العناصر للقائمة الثانية على سبيل المثال
  }

  void searchShoe(String query) {
    final suggestions = shoes.where((shoe) {
      final shoeName = shoe.name.toLowerCase();
      final input = query.toLowerCase();
      return shoeName.contains(input);
    }).toList();

    setState(() {
      filteredShoes = suggestions;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Zoo'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              onChanged: searchShoe,
              decoration: InputDecoration(
                hintText: 'Search shoes',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
                suffixIcon: Icon(Icons.search),
              ),
            ),
          ),

          // Horizontal List of Cards (First List)
          Container(
            height: 220,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: filteredShoes.length,
              itemBuilder: (context, index) {
                final shoe = filteredShoes[index];
                return ShoeCard(shoe: shoe);
              },
            ),
          ),

          // Vertical List of Cards (Second List using ListView.builder)
          Expanded(
            child: ListView.builder(
              itemCount: secondList.length,
              itemBuilder: (context, index) {
                final shoe = secondList[index];
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ShoeCard extends StatelessWidget {
  final Shoe shoe;

  const ShoeCard({Key? key, required this.shoe}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(8),
      width: 130,
      height: 180,
      child: Card(
        elevation: 3,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image(image: AssetImage('assets/images/img.png'),width: 100,height: 100,),
            SizedBox(height: 8),
            Text(shoe.name, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            SizedBox(height: 4),
            Text("\$${shoe.price.toString()}", style: TextStyle(color: Colors.orange, fontSize: 12)),
            SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.star, color: Colors.yellow, size: 14),
                SizedBox(width: 4),
                Text(shoe.rating.toString(), style: TextStyle(fontSize: 12)),


              ],
            ),
          ],
        ),
      ),
    );
  }
}

class ShoeCardVertical extends StatelessWidget {
  final Shoe shoe;

  const ShoeCardVertical({Key? key, required this.shoe}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      height: 100,
      child: Card(
        elevation: 3,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Image.network(shoe.imageUrl, height: 80, width: 80, fit: BoxFit.cover),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(shoe.name, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                Text("\$${shoe.price.toString()}", style: TextStyle(color: Colors.orange)),
                Row(
                  children: [
                    Icon(Icons.star, color: Colors.yellow, size: 16),
                    SizedBox(width: 4),
                    Text(shoe.rating.toString(), style: TextStyle(fontSize: 14)),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

